package com.codingshuttle.youtube.hospitalManagement.entity.type;

public enum AuthProviderType {
    GOOGLE,
    GITHUB,
    FACEBOOK,
    TWITTER,
    EMAIL
}
