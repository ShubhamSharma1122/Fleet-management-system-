# spring-boot-data-jpa-hospital-management-system
Spring Boot Project to teach Spring Boot Data JPA with real-world Project (Hospital Management System)
